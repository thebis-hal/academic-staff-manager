/**
 * Lecurer is sub class of Teacher that have inisited four instance variable, a constructor which accepts seven parameter,
 *
 * @(np01nt4a230172 Bishal Sah)
 */
public class Lecturer extends Teacher {
    // Additional attributes
    private String department;//A variable for the department. 
    private int yearsOfExperience;//A variable for the years Of Experience.
    private int gradedScore;//A variable for the graded Score.
    private boolean hasGraded;//A variable for the hasGraded.

    // Constructor
    public Lecturer(int teacherId, String teacherName, String address, String workingType, String employmentStatus,
                   String department, int yearsOfExperience, int workingHours) {
        super(teacherId, teacherName, address, workingType, employmentStatus);
        this.department = department;
        this.yearsOfExperience = yearsOfExperience;
        this.gradedScore = 0;  // Default is 0
        this.hasGraded = false;  // Default is false
    }

    // Accessor methods
    public String getDepartment() { //This is greater method which returns value.
        return department;
    }

    public int getYearsOfExperience() { 
        return yearsOfExperience;
    }

    public int getGradedScore() { 
        return gradedScore;
    }

    public boolean hasGraded() { 
        return hasGraded;
    }

    // Mutator method for gradedScore
    public void setGradedScore(int gradedScore) {
        this.gradedScore = gradedScore;
    }

    // Method to grade assignments
    public void gradeAssignment(int score, String studentDepartment, int studentYearsOfExperience) { //This is display method which display the value of instance value.
        if (!hasGraded) {
            if (yearsOfExperience >= 5 && department.equals(studentDepartment)) {
                if (score >= 70) {
                    gradedScore = score;
                } else if (score >= 60) {
                    gradedScore = 60;
                } else if (score >= 50) {
                    gradedScore = 50;
                } else if (score >= 40) {
                    gradedScore = 40;
                } else {
                    gradedScore = 0;
                }
                
                hasGraded = true;
            } else {
                System.out.println("Lecturer is not eligible to grade assignments for the given criteria.");
            }
        }
    }

    // Method to display details of the Lecturer
    
    public void displayTeacherInfo() {
        super.displayTeacherInfo();  // Call the displayTeacherInfo method from the superclass
        System.out.println("Department: " + department);
        System.out.println("Years of Experience: " + yearsOfExperience);
        if (hasGraded) {
            System.out.println("Graded Score: " + gradedScore);
        } else {
            System.out.println("Graded Score: Not yet graded");
        }
    }
}

