/**
 *Teacher is a super class that have inlisited five instance variable, a constructor, five accesser method, two mutator method and a display method
  that prints the sutaible output.
 *
 * @(np01nt4a230172 Bishal Sah)
 */
public class Teacher {
    // Attributes
    private int teacherId; //A variable for the teacher Id.
    private String teacherName;//A variable for the teacher Name.
    private String address;//A variable for the address. 
    private String workingType;//A variable for the working Type.
    private String employmentStatus;//A variable for the employment Status.
    private int workingHours;//A variable for the working Hours.
    // Constructor methods 
    public Teacher(int teacherId, String teacherName, String address, String workingType, String employmentStatus) {
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.address = address;
        this.workingType = workingType;
        this.employmentStatus = employmentStatus;
    }

    // Accessor methods
    public int getTeacherId() { //This is greater method which returns value.
        return teacherId;
    }

    public String getTeacherName() { 
        return teacherName;
    }

    public String getAddress() { 
        return address;
    }

    public String getWorkingType() { 
        return workingType;
    }

    public String getEmploymentStatus() { 
        return employmentStatus;
    }

    public int getWorkingHours() { 
        return workingHours;
    }

    // Method to set working hours
    public void setWorkingHours(int newWorkingHours) {
        this.workingHours = newWorkingHours;
    }

    // This is display method which display the value of instance value.
    public void displayTeacherInfo() { 
        System.out.println("Teacher Id: " + teacherId);
        System.out.println("Teacher Name: " + teacherName);
        System.out.println("Address: " + address);
        System.out.println("Working Type: " + workingType);
        System.out.println("Employment Status: " + employmentStatus);
        
        if (workingHours == 0) {
            System.out.println("Working Hours: " + workingHours);
        } else {
            System.out.println("Working Hours: Not assigned");
        }
    }

}