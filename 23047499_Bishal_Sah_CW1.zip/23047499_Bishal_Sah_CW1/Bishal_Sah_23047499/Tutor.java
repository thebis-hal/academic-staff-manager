/**
 * Tutor is sub class of Teacher 
 *
 * @(np01nt4a230172 Bishal Sah)
 */
public class Tutor extends Teacher {
    // Additional attributes
    private double salary;//A variable for the salary. 
    private String specialization;//A variable for the specialization. 
    private String academicQualifications;//A variable for the academic Qualifications.
    private int performanceIndex;//A variable for the performance Index.
    private boolean isCertified;//A variable for the isCertified.

    // Constructor
    public Tutor(int teacherId, String teacherName, String address, String workingType, String employmentStatus,
                 int workingHours, double salary, String specialization, String academicQualifications, int performanceIndex) {
        super(teacherId, teacherName, address, workingType, employmentStatus);
        this.setWorkingHours(workingHours);  // Call the setter method from the superclass
        this.salary = salary;
        this.specialization = specialization;
        this.academicQualifications = academicQualifications;
        this.performanceIndex = performanceIndex;
        this.isCertified = false;  // Default is false
    }

    // Accessor methods
    public double getSalary() { //This is greater method which returns value.
        return salary;
    }

    public String getSpecialization() { 
        return specialization;
    }

    public String getAcademicQualifications() { 
        return academicQualifications;
    }

    public int getPerformanceIndex() { 
        return performanceIndex;
    }

    public boolean isCertified() { 
        return isCertified;
    }

    // Mutator method for salary and certification status
    public void setSalaryAndCertification(double newSalary, int newPerformanceIndex) {
        if (newPerformanceIndex > 5 && getWorkingHours() > 20) {
            double appraisalPercentage;
            if (newPerformanceIndex >= 5 && newPerformanceIndex <= 7) {
                appraisalPercentage = 0.05;
            } else if (newPerformanceIndex >= 8 && newPerformanceIndex <= 9) {
                appraisalPercentage = 0.1;
            } else {
                appraisalPercentage = 0.2;
            }

            salary = newSalary + ( newSalary * appraisalPercentage);
            isCertified = true;
        } else {
            System.out.println("Tutor is not certified yet. Salary cannot be approved. ");
        }
    }

    // Method to remove the tutor
    public void removeTutor() {
        if (!isCertified) {
            salary = 0;
            specialization = "";
            academicQualifications = "";
            performanceIndex = 0;
            isCertified = false;
        } 
    }

    // Method to display details of the Tutor
    
    public void displayTeacherInfo() { //This is display method which display the value of instance value.
        super.displayTeacherInfo();  // Call the displayTeacherInfo method from the superclass
        if (isCertified) { //super class display method 
            System.out.println("Salary: $" + salary);
            System.out.println("Specialization: " + specialization);
            System.out.println("Academic Qualifications: " + academicQualifications);
            System.out.println("Performance Index: " + performanceIndex);
        }
    }
}

