public class Teacher {
    // Attributes
    private int teacherId; //a variable for the teacher Id.
    private String teacherName;//a variable for the teacher Name.
    private String address;//a variable for the address. 
    private String workingType;//a variable for the working Type.
    private String employmentStatus;//a variable for the employment Status.
    private int workingHours;//a variable for the working Hours.
    // Constructor that takes one int parameters (i.e teacherid) and four String.
    public Teacher(int teacherId, String teacherName, String address, String workingType, String employmentStatus) {
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.address = address;
        this.workingType = workingType;
        this.employmentStatus = employmentStatus;
    }

    // Accessor methods
    public int getTeacherId() { //This is greater method which returns value.
        return teacherId;
    }

    public String getTeacherName() { //This is greater method which returns value.
        return teacherName;
    }

    public String getAddress() { //This is greater method which returns value.
        return address;
    }

    public String getWorkingType() { //This is greater method which returns value.
        return workingType;
    }

    public String getEmploymentStatus() { //This is greater method which returns value.
        return employmentStatus;
    }

    public int getWorkingHours() { //This is greater method which returns value.
        return workingHours;
    }

    // Method to set working hours
    public void setWorkingHours(int newWorkingHours) {
        this.workingHours = newWorkingHours;
    }

    // Display method
    public void displayTeacherInfo() { //This is display method which display the value of instance value.
        System.out.println("Teacher Id: " + teacherId);
        System.out.println("Teacher Name: " + teacherName);
        System.out.println("Address: " + address);
        System.out.println("Working Type: " + workingType);
        System.out.println("Employment Status: " + employmentStatus);
        
        if (workingHours > 0) {
            System.out.println("Working Hours: " + workingHours);
        } else {
            System.out.println("Working Hours: Not assigned");
        }
    }

}