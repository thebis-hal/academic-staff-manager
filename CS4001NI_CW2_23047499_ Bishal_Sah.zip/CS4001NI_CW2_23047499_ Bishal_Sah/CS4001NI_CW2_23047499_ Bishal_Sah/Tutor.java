public class Tutor extends Teacher {
    // Additional attributes
    private double salary;//a variable for the salary. 
    private String specialization;//a variable for the specialization. 
    private String academicQualifications;//a variable for the academic Qualifications.
    private int performanceIndex;//a variable for the performance Index.
    private boolean isCertified;//a variable for the isCertified.

    // Constructor
    public Tutor(int teacherId, String teacherName, String address, String workingType, String employmentStatus,
                 int workingHours, double salary, String specialization, String academicQualifications, int performanceIndex) {
        super(teacherId, teacherName, address, workingType, employmentStatus);
        this.setWorkingHours(workingHours);  // Call the setter method from the superclass
        this.salary = salary;
        this.specialization = specialization;
        this.academicQualifications = academicQualifications;
        this.performanceIndex = performanceIndex;
        this.isCertified = false;  // Default is false
    }

    // Accessor methods
    public double getSalary() { //This is greater method which returns value.
        return salary;
    }

    public String getSpecialization() { //This is greater method which returns value.
        return specialization;
    }

    public String getAcademicQualifications() { //This is greater method which returns value.
        return academicQualifications;
    }

    public int getPerformanceIndex() { //This is greater method which returns value.
        return performanceIndex;
    }

    public boolean isCertified() { //This is greater method which returns value.
        return isCertified;
    }

    // Mutator method for salary
    public void setSalary(int newSalary, int newPerformanceIndex) {
        if (!isCertified) {
            if (newPerformanceIndex > 5 && getWorkingHours() > 20) {
                double appraisalPercentage;
                if (newPerformanceIndex >= 5 && newPerformanceIndex <= 7) {
                    appraisalPercentage = 0.05;
                } else if (newPerformanceIndex >= 8 && newPerformanceIndex <= 9) {
                    appraisalPercentage = 0.10;
                } else {
                    appraisalPercentage = 0.20;
                }

                double appraisalAmount = newSalary * appraisalPercentage;
                this.salary += appraisalAmount;
                this.isCertified = true;
                this.performanceIndex = newPerformanceIndex;
            } else {
                System.out.println("Salary cannot be approved. Tutor does not meet the criteria.");
            }
        } else {
            System.out.println("Salary cannot be updated for a certified tutor.");
        }
    }

    // Method to remove the tutor
    public void removeTutor() {
        if (!isCertified) {
            this.salary = 0;
            this.specialization = "";
            this.academicQualifications = "";
            this.performanceIndex = 0;
            this.isCertified = false;
        } else {
            System.out.println("Certified tutor cannot be removed.");
        }
    }

    // Method to display details of the Tutor
    
    public void displayTeacherInfo() { //This is display method which display the value of instance value.
        super.displayTeacherInfo();  // Call the displayTeacherInfo method from the superclass
        if (isCertified) {
            System.out.println("Salary: $" + salary);
            System.out.println("Specialization: " + specialization);
            System.out.println("Academic Qualifications: " + academicQualifications);
            System.out.println("Performance Index: " + performanceIndex);
        } else {
            System.out.println("Certification Status: Not certified yet");
        }
    }
}

