import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;//import event ActionEvent from java.awt package
import java.awt.event.ActionListener;//import event ActionListener from java.awt package
import java.util.ArrayList;
import javax.swing.JFrame; // import JFrame from javax.swing package
import javax.swing.JPanel;//import JPanel from javax.swing package
import java.awt.Color;// import Color from java.awt package
import javax.swing.JButton;//import JButton from javax.swing package

public class TeacherGUI extends JFrame {
    private JFrame frame;
    private JLabel namasteLabel;
    private JLabel greatLabel;
    
    private ArrayList<Teacher> tlist = new ArrayList<Teacher>();
    
    public TeacherGUI() {
        JPanel mainPanel = new JPanel();
        
        // Addding text fields, labels, Button here

        JButton addLecturerButton = new JButton("LECTURER");
        addLecturerButton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
                {
                // Create a new Lecturer object and add it to the teachers array list
                JFrame f = new JFrame("LECTURER");
                f.setVisible(true);
                f.setSize(800, 600);
                f.setLayout(null);
                
                JPanel p = new JPanel();
                p.setLayout(null);
                f.add(p);
                
                JLabel L0 = new JLabel("LECTURER");
                L0.setBounds(300, -20, 200,70);
                L0.setFont(new Font("Algerian", Font.BOLD,27)); 
                L0.setForeground(Color.BLUE);
                f.add(L0);
        
                JLabel L1 = new JLabel("Teacher Id: ");
                L1.setBounds(30, 50, 100, 30);
                f.add(L1);
        
                JTextField T1 = new JTextField();
                T1.setBounds(175, 50, 150, 30);
                f.add(T1);
        
                JLabel L2 = new JLabel("Teacher Name: ");
                L2.setBounds(30, 100, 100, 30);
                f.add(L2);
        
                JTextField T2 = new JTextField();
                T2.setBounds(175, 100, 150, 30);
                f.add(T2);
        
                JLabel L3 = new JLabel("Teacher Address: ");
                L3.setBounds(30, 150, 120, 30);
                f.add(L3);
                
                JTextField T3 = new JTextField();
                T3.setBounds(175, 150, 150, 30);
                f.add(T3);
                
                JLabel L4 = new JLabel("Working Type: ");
                L4.setBounds(400, 50, 100, 30);
                f.add(L4);
        
                JTextField T4 = new JTextField();
                T4.setBounds(550, 50, 150, 30);
                f.add(T4);
        
                JLabel L5 = new JLabel("Employment Status: ");
                L5.setBounds(400, 100, 120, 30);
                f.add(L5);
        
                JTextField T5 = new JTextField();
                T5.setBounds(550, 100, 150, 30);
                f.add(T5);
                
                JLabel L6 = new JLabel("Department: ");
                L6.setBounds(400, 150, 100, 30);
                f.add(L6);
        
                JTextField T6 = new JTextField();
                T6.setBounds(550, 150, 150, 30);
                f.add(T6);
                
                JLabel L7 = new JLabel("Year of Experience: ");
                L7.setBounds(400, 200, 120, 30);
                f.add(L7);
        
                JTextField T7 = new JTextField();
                T7.setBounds(550, 200, 150, 30);
                f.add(T7);
                
                JLabel L8 = new JLabel("Department: ");
                L8.setBounds(80, 325, 100, 30);
                f.add(L8);
        
                JTextField T8 = new JTextField();
                T8.setBounds(175, 325, 150, 30);
                f.add(T8);
                
                JLabel L9 = new JLabel("Working Hours: ");
                L9.setBounds(30, 200, 120, 30);
                f.add(L9);
        
                JTextField T9 = new JTextField();
                T9.setBounds(175, 200, 150, 30);
                f.add(T9);
                
                JLabel L10 = new JLabel("Year of Experience: ");
                L10.setBounds(370, 325, 120, 30);
                f.add(L10);
        
                JTextField T10 = new JTextField();
                T10.setBounds(500, 325, 150, 30);
                f.add(T10);
                
                JLabel L11 = new JLabel("Score: ");
                L11.setBounds(140, 375, 300, 30);
                f.add(L11);
        
                JTextField T11 = new JTextField();
                T11.setBounds(195, 375, 150, 30);
                f.add(T11);
        
                JButton B1 = new JButton("Add Lecturer");
                B1.setBounds(275, 250, 250, 30);
                B1.setFont(new Font("Arial Black", Font.BOLD,14));
                B1.setBackground(Color.GREEN);
                f.add(B1);
        
                JButton B2 = new JButton("Grade Assignment");
                B2.setBounds(250, 425, 300, 30);
                B2.setFont(new Font("Arial Black", Font.BOLD,14));
                B2.setBackground(Color.GREEN);
                f.add(B2);
                
                JButton B3 = new JButton("Display");
                B3.setBounds(70, 475, 100, 30);
                B3.setFont(new Font("Arial Black", Font.BOLD,14));
                B3.setBackground(Color.WHITE);
                f.add(B3);
        
                JButton B4 = new JButton("Clear");
                B4.setBounds(600, 475, 100, 30);
                B4.setFont(new Font("Arial Black", Font.BOLD,14));
                B4.setBackground(Color.RED);
                f.add(B4);
             
                B1.addActionListener(new ActionListener() 
            {
                public void actionPerformed(ActionEvent ae) 
                {
                    try {
                        int teacherId = Integer.parseInt(T1.getText());
                        String teacherName = T2.getText();
                        String address = T3.getText();
                        String workingType = T4.getText();
                        String employmentStatus = T5.getText();
                        int yearsOfExperience = Integer.parseInt(T7.getText());
                        String department = T6.getText();
                        int workingHours = Integer.parseInt(T9.getText());
                        
                        // Check if the teacher ID is already assigned
                        boolean idExists = false;
                        for (Teacher t : tlist) {
                            if (t.getTeacherId() == teacherId) {
                                idExists = true;
                                break;
                            }
                        }
                        if (idExists) {
                            JOptionPane.showMessageDialog(TeacherGUI.this, "The ID " + teacherId + " is already assigned.");
                        } else {
                            Lecturer lecturer = new Lecturer(teacherId,teacherName,address,workingType,employmentStatus,department,yearsOfExperience,workingHours);
                            
                            tlist.add(lecturer);
                            JOptionPane.showMessageDialog(TeacherGUI.this, "Lecturer added successfully!");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(TeacherGUI.this, "Invalid input. Please Fill all the fields.");
                    }
                }
            });

            
            B2.addActionListener(new ActionListener() 
            {
              public void actionPerformed(ActionEvent ae) 
              {
                    try{ 
                      int Score = Integer.parseInt(T11.getText());
                      String department = T8.getText();
                      int yearsOfExperience = Integer.parseInt(T10.getText());
                      for(Teacher t :tlist){
                            if (t instanceof Lecturer){
                                Lecturer L1 = (Lecturer) t;
                                L1.gradeAssignment(Score,department,yearsOfExperience);

                            }
                        }
                        JOptionPane.showMessageDialog(null, "!!!Thank You!!! Graded Score Sucessfull");
                    } catch(Exception e){
                        JOptionPane.showMessageDialog(null, "enter Correct Information to Add Graded Score");
                  }
                }
            });
            
            B3.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent ae) 
                {
                    for(Teacher t : tlist)
                    {
                      if(t instanceof Lecturer)
                      {
                          t.displayTeacherInfo();
                      }
                    }
                }
            
            });
            
            B4.addActionListener(new ActionListener() 
            {
                public void actionPerformed(ActionEvent ae) {
                        T1.setText("");
                        T2.setText("");
                        T3.setText("");
                        T4.setText("");
                        T5.setText("");
                        T6.setText("");
                        T7.setText("");
                        T8.setText("");
                        T9.setText("");
                        T10.setText("");
                        T11.setText("");
                        JOptionPane.showMessageDialog(null, "Cleared");
                    }
            });
            
            
         }
        });
   
        JButton addTutorButton = new JButton("TUTOR");
        addTutorButton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                // Create a new Tutor object and add it to the teachers array list
                JFrame f = new JFrame("TUTOR");
                f.setVisible(true);
                f.setSize(800, 600);
                f.setLayout(null);
                
                JPanel p = new JPanel();
                p.setLayout(null);
                f.add(p);
                
                JLabel L0 = new JLabel("TUTOR");
                L0.setBounds(350, -20, 100,70);
                L0.setFont(new Font("Algerian", Font.BOLD,27)); 
                L0.setForeground(Color.BLUE);
                f.add(L0);
                
                JLabel L1 = new JLabel("Teacher Id: ");
                L1.setBounds(50, 50, 100, 30);
                f.add(L1);
        
                JTextField T1 = new JTextField();
                T1.setBounds(175, 50, 150, 30);
                f.add(T1);
        
                JLabel L2 = new JLabel("Teacher Name: ");
                L2.setBounds(50, 100, 100, 30);
                f.add(L2);
        
                JTextField T2 = new JTextField();
                T2.setBounds(175, 100, 150, 30);
                f.add(T2);
        
                JLabel L3 = new JLabel("Address: ");
                L3.setBounds(50, 150, 100, 30);
                f.add(L3);
                
                JTextField T3 = new JTextField();
                T3.setBounds(175, 150, 150, 30);
                f.add(T3);
        
                
                JLabel L4 = new JLabel("Working Hours: ");
                L4.setBounds(50, 200, 100, 30);
                f.add(L4);
                
                JTextField T4 = new JTextField();
                T4.setBounds(175, 200, 150, 30);
                f.add(T4);
                
                JLabel L5 = new JLabel("Working Type: ");
                L5.setBounds(400, 50, 100, 30);
                f.add(L5);
        
                JTextField T5 = new JTextField();
                T5.setBounds(550, 50, 150, 30);
                f.add(T5);
        
                JLabel L6 = new JLabel("Employment Status: ");
                L6.setBounds(400, 100, 120, 30);
                f.add(L6);
        
                JTextField T6 = new JTextField();
                T6.setBounds(550, 100, 150, 30);
                f.add(T6);
                
                JLabel L7 = new JLabel("Salary: ");
                L7.setBounds(400, 150, 100, 30);
                f.add(L7);
        
                JTextField T7 = new JTextField();
                T7.setBounds(550, 150, 150, 30);
                f.add(T7);
                
                JLabel L8 = new JLabel("Specialization: ");
                L8.setBounds(50, 250, 100, 30);
                f.add(L8);
        
                JTextField T8 = new JTextField();
                T8.setBounds(175, 250, 150, 30);
                f.add(T8);
                
                JLabel L9 = new JLabel("Academic Qualifications: ");
                L9.setBounds(400, 200, 150, 30);
                f.add(L9);
        
                JTextField T9 = new JTextField();
                T9.setBounds(550, 200, 150, 30);
                f.add(T9);
                
                JLabel L10 = new JLabel("Preformance Index: ");
                L10.setBounds(400, 250, 150, 30);
                f.add(L10);
        
                JTextField T10 = new JTextField();
                T10.setBounds(550, 250, 150, 30);
                f.add(T10);
                
                JLabel L11 = new JLabel("New Salary: ");
                L11.setBounds(80, 385, 150, 30);
                f.add(L11);
        
                JTextField T11 = new JTextField();
                T11.setBounds(175, 385, 150, 30);
                f.add(T11);
                
                JLabel L12 = new JLabel("New Preformance Index: ");
                L12.setBounds(350, 385, 150, 30);
                f.add(L12);
        
                JTextField T12 = new JTextField();
                T12.setBounds(500, 385, 150, 30);
                f.add(T12);
        
                JButton B1 = new JButton("Add Tutor");
                B1.setBounds(50, 310, 175, 30);
                B1.setFont(new Font("Arial Black", Font.BOLD,14));
                B1.setBackground(Color.GREEN);
                f.add(B1);
        
                JButton B2 = new JButton("Remove Tutor");
                B2.setBounds(500, 310, 175, 30);
                B2.setFont(new Font("Arial Black", Font.BOLD,14));
                B2.setBackground(Color.GREEN);
                f.add(B2);
                
                JButton B3 = new JButton("Set Salary");
                B3.setBounds(280, 450, 200, 30);
                B3.setFont(new Font("Arial Black", Font.BOLD,14));
                B3.setBackground(Color.GREEN);
                f.add(B3);
                
                JButton B4 = new JButton("Display");
                B4.setBounds(75, 500, 100, 30);
                B4.setFont(new Font("Arial Black", Font.BOLD,14));
                B4.setBackground(Color.WHITE);
                f.add(B4);
        
                JButton B5 = new JButton("Clear");
                B5.setBounds(540, 500, 100, 30);
                B5.setFont(new Font("Arial Black", Font.BOLD,14));
                B5.setBackground(Color.RED);
                f.add(B5);
                B1.addActionListener(new ActionListener() 
                {
                    public void actionPerformed(ActionEvent ae) 
                    {
                        try {
                        int teacherId = Integer.parseInt(T1.getText());
                        String teacherName = T2.getText();
                        String address = T3.getText();
                        int workingHours = Integer.parseInt(T4.getText());
                        String workingType = T5.getText();
                        String employmentStatus = T6.getText();
                        double salary = Double.parseDouble(T7.getText());
                        String specialization = (T8.getText());
                        String academicQualifications = T9.getText();
                        int performanceIndex = Integer.parseInt(T10.getText());

                        Tutor tutor = new Tutor(teacherId,teacherName,address,workingType,employmentStatus,workingHours,salary,specialization,academicQualifications,performanceIndex);
                        tlist.add(tutor);

                        JOptionPane.showMessageDialog(TeacherGUI.this, " !!!Thank You!!! Tutor added successfully!");
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(TeacherGUI.this, "Invalid input.Enter Correct Information of Tutor To Add Tutor .");
                        }
                    }
                });
                
                B1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ae) {
                        try {
                            int teacherId = Integer.parseInt(T1.getText());
                            String teacherName = T2.getText();
                            String address = T3.getText();
                            int workingHours = Integer.parseInt(T4.getText());
                            String workingType = T5.getText();
                            String employmentStatus = T6.getText();
                            double salary = Double.parseDouble(T7.getText());
                            String specialization = T8.getText();
                            String academicQualifications = T9.getText();
                            int performanceIndex = Integer.parseInt(T10.getText());
                
                            // Check if the teacher ID is already assigned
                            boolean idExists = false;
                            for (Teacher tutor : tlist) {
                                if (tutor.getTeacherId() == teacherId) {
                                    idExists = true;
                                    break;
                                }
                            }
                
                            if (idExists) {
                                JOptionPane.showMessageDialog(TeacherGUI.this, "The ID you provided is already assigned.");
                            } else {
                                Tutor tutor = new Tutor(teacherId, teacherName, address, workingType, employmentStatus, workingHours, salary, specialization, academicQualifications, performanceIndex);
                                tlist.add(tutor);
                                JOptionPane.showMessageDialog(TeacherGUI.this, " !!!Thank You!!! Tutor added successfully!");
                            }
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(TeacherGUI.this, "Invalid input. Enter correct information of Tutor to add Tutor.");
                        }
                    }
                });

            
                B2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ae) {
                        try {
                            int teacherId = Integer.parseInt(T1.getText()); 
                            for(Teacher t : tlist)
                            {
                                if (t.getTeacherId()== teacherId && t instanceof Tutor)
                                {
                                    Tutor tutor = (Tutor)t;
                                    tutor.removeTutor();
                                    JOptionPane.showMessageDialog(null, " !!!Tutor Removed successfully!!!");
                                    break; // Break the loop after removing the tutor
                                }
                            }
                        }
                        catch(Exception e){
                            JOptionPane.showMessageDialog(null, "Please do not leave fields empty...");
                        }
                    }
                });

                
                
                B3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ae) {
                        for (Teacher t : tlist){
                            try{
                                int newSalary = Integer.parseInt(T11.getText());
                                int newPerformanceIndex = Integer.parseInt(T12.getText());
                                Tutor T1 = (Tutor) t;
                                T1.setSalary(newSalary,newPerformanceIndex);
                                JOptionPane.showMessageDialog(null, "!!!Thank You!!! ");
                            } catch(Exception e){
                                JOptionPane.showMessageDialog(null, "Enter Correct Information");

                            }
                        }
                    }
               });
       
                
                B4.addActionListener(new ActionListener() 
                {
                    public void actionPerformed(ActionEvent ae) 
                    {
                    for(Teacher t : tlist)
                    {
                      if(t instanceof Tutor)
                      {
                          t.displayTeacherInfo();
                      }
                    }
                    }
                });

                B5.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent ae) 
                    {
                        T1.setText("");
                        T2.setText("");
                        T3.setText("");
                        T4.setText("");
                        T5.setText("");
                        T6.setText("");
                        T7.setText("");
                        T8.setText("");
                        T9.setText("");
                        T10.setText("");
                        T11.setText("");
                        T12.setText("");
                        
                        JOptionPane.showMessageDialog(null, "Cleared");
                    }
                });
                }
        });
        
        
        Color colorPanel1 = new Color( 241,235,156);
        mainPanel.setBackground(colorPanel1);
        
        mainPanel.setLayout(null);
        mainPanel.setOpaque(true);
        add(mainPanel);
        
        //JLabel for Bank GUI Interface
        namasteLabel = new JLabel("!!! Namaste Admin !!!");
        namasteLabel.setBounds( 100, 60, 400, 20);
        namasteLabel.setForeground( Color.DARK_GRAY);
        namasteLabel.setFont(new Font("Castellar", Font.BOLD,24));
        mainPanel.add(namasteLabel);
       
        //JLabel for Bank GUI Interface
        greatLabel = new JLabel("Have a Great Day Ahead");
        greatLabel.setBounds( 90, 90, 500, 20);
        greatLabel.setForeground( Color.DARK_GRAY);
        greatLabel.setFont(new Font("Castellar", Font.BOLD,20));
        mainPanel.add(greatLabel);
        
        mainPanel.add(addLecturerButton);
        Color colorbtn = new Color( 123,194,87);
        addLecturerButton.setBackground(colorbtn);
        addLecturerButton.setBounds(100, 145, 300, 80);
        addLecturerButton.setFont(new Font("Arial Black", Font.BOLD,25)); 
        
        mainPanel.add(addTutorButton);
        Color color1 = new Color( 123,194,87);
        addTutorButton.setBackground(color1);
        addTutorButton.setBounds(100, 235, 300, 80);
        addTutorButton.setFont(new Font("Arial Black", Font.BOLD,25));
        
        setTitle("Teacher GUI");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new TeacherGUI();
    }
}